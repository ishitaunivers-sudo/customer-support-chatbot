"""Tiny intent-tagged knowledge base. Swap for a vector store (pgvector, etc.) in production."""
import re
KB = [
 {"id": "KB-101", "intent": "delivery_delay", "text": "If a package is delayed, share live tracking and the revised ETA. If more than 7 days late, offer reship or refund."},
 {"id": "KB-102", "intent": "payment_failed", "text": "Failed payments are usually bank declines or expired cards. Ask the customer to retry or update the card; the order is held for 24 hours."},
 {"id": "KB-103", "intent": "refund", "text": "Refunds are issued to the original payment method within 5-7 business days after the return is received. Returns are accepted within 30 days."},
 {"id": "KB-104", "intent": "cancel", "text": "Orders can be cancelled before shipping at no charge. Subscriptions end at the close of the billing cycle."},
 {"id": "KB-105", "intent": "account_access", "text": "Use 'Forgot password' to receive a reset link. Accounts lock for 30 minutes after 5 failed attempts."},
 {"id": "KB-106", "intent": "technical", "text": "Restart the device, check the service status page, and confirm the latest app version. Persistent outages create a ticket automatically."},
 {"id": "KB-107", "intent": "billing_dispute", "text": "Duplicate or incorrect charges are reviewed within 3 business days; the customer is credited if the error is confirmed."},
]
def retrieve(intent, query):
    q = set(re.findall(r"\w{4,}", query.lower()))
    best, score = None, 0.0
    for d in KB:
        if d["intent"] != intent: continue
        ov = len(q & set(re.findall(r"\w{4,}", d["text"].lower())))
        s = 0.6 + 0.4 * min(1, ov / 2)
        if s > score: best, score = d, s
    return best, score
