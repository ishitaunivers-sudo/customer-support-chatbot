"""LLM backends. Offline template backend by default; Claude (or a fine-tuned model) via env."""
import os
class TemplateLLM:
    def rewrite(self, draft, lang, tone): return draft
class AnthropicLLM:
    """Polishes drafts in the customer's language/tone. Needs `pip install anthropic` + ANTHROPIC_API_KEY."""
    def __init__(self, model=None):
        import anthropic
        self.c, self.model = anthropic.Anthropic(), model or os.getenv("SUPPORT_MODEL", "claude-sonnet-5-5")
    def rewrite(self, draft, lang, tone):
        r = self.c.messages.create(model=self.model, max_tokens=400,
            system=f"You are a support agent. Rewrite the draft in language '{lang}', tone '{tone}'. Keep every fact, add none.",
            messages=[{"role": "user", "content": draft}])
        return r.content[0].text
