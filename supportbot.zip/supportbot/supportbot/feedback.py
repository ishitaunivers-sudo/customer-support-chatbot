"""Surveys + closed-loop learning: CSAT -> fine-tune data, review queue, threshold tuning."""
import json, statistics as st
SURVEY = {"en": ["How satisfied are you with this support (1-5)?", "How likely are you to recommend us (0-10)?", "Anything we could do better?"],
          "es": ["¿Qué tan satisfecho está con la atención (1-5)?", "¿Nos recomendaría (0-10)?", "¿Algo que mejorar?"],
          "fr": ["Quel est votre niveau de satisfaction (1-5)?", "Nous recommanderiez-vous (0-10)?", "Un commentaire?"]}
def build_survey(conv): return {"conversation_id": conv.id, "questions": SURVEY.get(conv.lang, SURVEY["en"])}

class FeedbackStore:
    def __init__(self, path="feedback.jsonl"): self.path, self.rows = path, []
    def record(self, conv, csat, nps=None, comment="", agent_resolution=None):
        row = {"id": conv.id, "csat": csat, "nps": nps, "comment": comment, "escalated": conv.escalated,
               "intent": conv.last_intent, "lang": conv.lang, "turns": conv.turns, "agent_resolution": agent_resolution}
        self.rows.append(row)
        with open(self.path, "a", encoding="utf-8") as f: f.write(json.dumps(row, ensure_ascii=False) + "\n")
    def export_training(self, sft_path="sft.jsonl", review_path="review_queue.jsonl"):
        """High-CSAT bot chats + human-agent fixes -> SFT; low-CSAT bot chats -> human review."""
        sft = review = 0
        with open(sft_path, "w", encoding="utf-8") as s, open(review_path, "w", encoding="utf-8") as r:
            for x in self.rows:
                msgs = [{"role": "user" if t["role"] == "customer" else "assistant", "content": t["text"]} for t in x["turns"]]
                if x["agent_resolution"]: msgs[-1] = {"role": "assistant", "content": x["agent_resolution"]}
                if (x["csat"] >= 4 and not x["escalated"]) or x["agent_resolution"]:
                    s.write(json.dumps({"messages": msgs, "intent": x["intent"]}, ensure_ascii=False) + "\n"); sft += 1
                elif x["csat"] <= 2:
                    r.write(json.dumps(x, ensure_ascii=False) + "\n"); review += 1
        return {"sft_examples": sft, "needs_review": review}
    def tune_threshold(self, current):
        bot = [x["csat"] for x in self.rows if not x["escalated"]]
        esc_rate = sum(x["escalated"] for x in self.rows) / max(1, len(self.rows))
        if bot and st.mean(bot) < 3.5: return round(current + 0.05, 2)   # bot over-reaching
        if bot and st.mean(bot) > 4.3 and esc_rate > 0.4: return round(current - 0.05, 2)  # over-escalating
        return current
