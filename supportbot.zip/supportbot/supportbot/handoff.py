import json, time
class HandoffQueue:
    """Hands a human agent everything so the customer never repeats themselves."""
    def __init__(self): self.queue = []
    def submit(self, conv, reason, suggested, profile):
        packet = {
            "conversation_id": conv.id, "created": time.time(), "reason": reason,
            "priority": "high" if conv.sentiment.ema < -0.5 or reason == "high_risk" else "normal",
            "customer": profile, "language": conv.lang,
            "issue": {"intent": conv.last_intent, "sentiment_now": conv.sentiment.history[-1:], "trend": conv.sentiment.trend},
            "transcript": conv.turns, "suggested_resolution": suggested,
            "summary": f"{conv.last_intent} | sentiment {conv.sentiment.trend} | escalated: {reason} | {len(conv.turns)} turns",
        }
        self.queue.append(packet); return packet
    def dump(self, packet): return json.dumps(packet, indent=2, ensure_ascii=False)
